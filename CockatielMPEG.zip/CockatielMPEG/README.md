<p align="center"><img src="app/src/main/res/mipmap-xxxhdpi/ic_launcher.png" width="128" alt="icon"></p>

# 🦜 CockatielMPEG

Make videos with FFmpeg on Android: put text on a video, or run your own FFmpeg commands.

**Version:** 0.0.0.2

## Two builds
| Build | Android | Look |
|---|---|---|
| `CockatielMPEG-0.0.0.2.apk` | 9+ | Command Prompt theme |
| `CockatielMPEG-0.0.0.2-legacy.apk` | 5+ | Old-style Holo UI |

Both can be installed side by side.

## Features
- Simple mode: upload a video or image, type text (emoji, Arabic, Persian and Cyrillic work, long text wraps)
- FFmpeg command mode: type your own arguments, use `{input}` and `{output}`
- Presets: create a preset (name, command, save folder), pick it later from Select preset
- Dark progress bar and a Cancel button
- Live FFmpeg log, built-in player, Save button
- Languages: English, Arabic, Russian, Persian, LOLCAT
- Credits menu

## Build
Push to GitHub and the Actions workflow builds both APKs (`gradle assembleDebug`).

## Known bugs
- Output is `mpeg4`, not `h264`. Image clips are fixed at 5 seconds, with no audio.
- Progress is based on the input length, so it can be off for trimmed commands.
- Rotating the screen may clear the log (normal build).
- Translations are AI-made. Corrections welcome.
