package com.cockatiel.mpeg

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts.GetContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { Surface { App() } } }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var input by remember { mutableStateOf<File?>(null) }
    var isImage by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("No file selected") }
    var text by remember { mutableStateOf("") }
    var log by remember { mutableStateOf("") }
    var output by remember { mutableStateOf<File?>(null) }
    var busy by remember { mutableStateOf(false) }
    val logScroll = rememberScrollState()
    LaunchedEffect(log) { logScroll.scrollTo(logScroll.maxValue) }

    val picker = rememberLauncherForActivityResult(GetContent()) { uri: Uri? ->
        if (uri != null) scope.launch(Dispatchers.IO) {
            val f = File(ctx.cacheDir, "input_file")
            ctx.contentResolver.openInputStream(uri)?.use { i -> f.outputStream().use { i.copyTo(it) } }
            isImage = ctx.contentResolver.getType(uri)?.startsWith("image") == true
            name = uri.lastPathSegment ?: "file"; input = f
        }
    }

    fun run() {
        val inp = input ?: return
        busy = true; log = ""; output = null
        val out = File(ctx.cacheDir, "out_${System.currentTimeMillis()}.mp4")
        val tf = File(ctx.cacheDir, "text.txt").apply { writeText(text) }
        val vf = buildString {
            append("scale=trunc(iw/2)*2:trunc(ih/2)*2,format=yuv420p")
            if (text.isNotBlank()) append(",drawtext=fontfile=/system/fonts/Roboto-Regular.ttf:textfile=${tf.absolutePath}:fontcolor=white:fontsize=h/12:box=1:boxcolor=black@0.5:x=(w-text_w)/2:y=h-text_h-40")
        }
        val pre = if (isImage) "-loop 1 -t 5 -r 25 " else ""
        val cmd = "-y ${pre}-i ${inp.absolutePath} -vf \"$vf\" -c:v mpeg4 -q:v 3 -c:a aac ${out.absolutePath}"
        FFmpegKit.executeAsync(cmd, { s ->
            busy = false
            if (ReturnCode.isSuccess(s.returnCode)) { output = out; log += "\nDONE ✔" } else log += "\nFAILED ✘"
        }, { l -> log += l.message }, null)
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp).statusBarsPadding(),
        verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("🦜 CockatielMPEG", style = MaterialTheme.typography.headlineMedium)
        Button(onClick = { picker.launch("*/*") }, Modifier.fillMaxWidth()) { Text("Upload video / image") }
        Text(name, style = MaterialTheme.typography.bodySmall)
        OutlinedTextField(text, { text = it }, Modifier.fillMaxWidth(), label = { Text("Text to put on the video") })
        Button(onClick = { run() }, Modifier.fillMaxWidth(), enabled = input != null && !busy) {
            Text(if (busy) "Rendering…" else "Make video")
        }
        Text("Log", style = MaterialTheme.typography.titleSmall)
        Box(Modifier.fillMaxWidth().height(180.dp).verticalScroll(logScroll)) {
            Text(log, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
        }
        output?.let { f ->
            Player(f)
            OutlinedButton(onClick = { save(ctx, f) }, Modifier.fillMaxWidth()) { Text("Save to Movies") }
        }
    }
}

@Composable
fun Player(file: File) {
    val ctx = LocalContext.current
    val player = remember(file) {
        ExoPlayer.Builder(ctx).build().apply {
            setMediaItem(MediaItem.fromUri(Uri.fromFile(file))); prepare(); playWhenReady = true
        }
    }
    DisposableEffect(player) { onDispose { player.release() } }
    AndroidView({ PlayerView(it) }, Modifier.fillMaxWidth().height(260.dp), update = { it.player = player })
}

fun save(ctx: Context, f: File) {
    val v = ContentValues().apply {
        put(MediaStore.Video.Media.DISPLAY_NAME, f.name)
        put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
        put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/CockatielMPEG")
    }
    val uri = ctx.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v) ?: return
    ctx.contentResolver.openOutputStream(uri)?.use { o -> f.inputStream().use { it.copyTo(o) } }
    Toast.makeText(ctx, "Saved to Movies/CockatielMPEG", Toast.LENGTH_SHORT).show()
}
