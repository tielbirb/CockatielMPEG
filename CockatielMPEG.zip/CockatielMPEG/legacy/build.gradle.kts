plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.cockatiel.mpeg.legacy"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.cockatiel.mpeg.legacy"
        minSdk = 21; targetSdk = 33; versionCode = 2; versionName = "0.0.0.2"
        ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a") }
    }
    sourceSets { getByName("main") { java.srcDir("../shared") } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    packaging { jniLibs.useLegacyPackaging = true }
}
dependencies {
    // LTS build of FFmpegKit: supports old Android (API 16+)
    implementation("io.github.jamaismagic.ffmpeg:ffmpeg-kit-lts-full-16kb:6.1.4")
}
