package com.cockatiel.mpeg.legacy

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.*
import com.cockatiel.mpeg.*
import java.io.File

class LegacyActivity : Activity() {
    var lang = defaultLang(); var mode = "simple"; var input: File? = null; var isImage = false; var name: String? = null
    var overlay = ""; var custom = "-f lavfi -i testsrc=duration=5:size=640x360:rate=25 -pix_fmt yuv420p {output}"
    var saveDir = ""; var pDir = ""; var jobId = 0L; var busy = false; var output: File? = null; var logBuf = ""
    var etText: EditText? = null; var etCmd: EditText? = null; var dirTv: TextView? = null
    lateinit var logTv: TextView; lateinit var pb: ProgressBar; lateinit var pct: TextView; lateinit var vv: VideoView
    lateinit var nameTv: TextView; lateinit var makeBtn: Button; lateinit var cancelBtn: Button; lateinit var saveBtn: Button
    val green = 0xFF16C60C.toInt()

    fun t(k: String) = tr(lang, k)
    fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    fun sync() { etText?.let { overlay = it.text.toString() }; etCmd?.let { custom = it.text.toString() } }
    fun log(s: String) = runOnUiThread { logBuf += s; logTv.append(s) }
    fun refresh() {
        makeBtn.isEnabled = !busy; cancelBtn.visibility = if (busy) View.VISIBLE else View.GONE
        pb.visibility = if (busy) View.VISIBLE else View.GONE; pct.visibility = pb.visibility
        saveBtn.visibility = if (output != null) View.VISIBLE else View.GONE
    }

    override fun onCreate(b: Bundle?) { super.onCreate(b); build() }

    fun build() {
        etText = null; etCmd = null
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(12), dp(12), dp(12)) }
        fun add(v: View) = root.addView(v, LinearLayout.LayoutParams(-1, -2))
        fun btn(label: String, f: () -> Unit) = Button(this).apply { text = label; setOnClickListener { sync(); f() } }
        add(TextView(this).apply { text = "CockatielMPEG $VERSION (legacy)"; textSize = 20f; setTextColor(green) })
        add(Spinner(this).apply {
            adapter = ArrayAdapter(this@LegacyActivity, android.R.layout.simple_spinner_item, LANGS.map { it.uppercase() })
            setSelection(LANGS.indexOf(lang))
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                    if (LANGS[pos] != lang) { sync(); lang = LANGS[pos]; window.decorView.post { build() } }
                }
                override fun onNothingSelected(p: AdapterView<*>?) {}
            }
        })
        add(RadioGroup(this).apply {
            orientation = RadioGroup.HORIZONTAL
            listOf("simple" to t("m_simple"), "cmd" to t("m_cmd")).forEach { (k, v) ->
                addView(RadioButton(context).apply { id = View.generateViewId(); text = v; isChecked = mode == k
                    setOnClickListener { sync(); mode = k; build() } })
            }
        })
        add(btn(t("presets")) { pickPreset() }); add(btn(t("pnew")) { createPreset() }); add(btn(t("credits")) {
            AlertDialog.Builder(this).setTitle(t("credits")).setMessage(CREDITS).setPositiveButton(t("close"), null).show() })
        add(btn(t("upload")) { startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("*/*"), 1) })
        nameTv = TextView(this).apply { text = name ?: t("none") }; add(nameTv)
        if (mode == "cmd") { etCmd = EditText(this).apply { typeface = Typeface.MONOSPACE; textSize = 12f; minLines = 3; hint = t("cmd_hint"); setText(custom) }; add(etCmd!!) }
        else { etText = EditText(this).apply { hint = t("hint"); setText(overlay) }; add(etText!!) }
        makeBtn = btn(t("make")) { run() }; add(makeBtn)
        cancelBtn = btn(t("cancel")) { cancelJob(jobId) }; add(cancelBtn)
        pb = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100; progressTintList = ColorStateList.valueOf(green); indeterminateTintList = ColorStateList.valueOf(green)
            progressBackgroundTintList = ColorStateList.valueOf(0xFF333333.toInt()) }
        add(pb); pct = TextView(this); add(pct)
        add(TextView(this).apply { text = t("log") })
        logTv = TextView(this).apply { textSize = 10f; typeface = Typeface.MONOSPACE; setTextColor(green); text = logBuf }
        root.addView(ScrollView(this).apply { addView(logTv) }, LinearLayout.LayoutParams(-1, dp(180)))
        vv = VideoView(this); root.addView(vv, LinearLayout.LayoutParams(-1, dp(240)))
        saveBtn = btn(t("save")) { Toast.makeText(this, "${t("saved")} ${save(this, output!!)}", Toast.LENGTH_LONG).show() }; add(saveBtn)
        vv.visibility = View.GONE
        output?.let { play(it) }
        refresh()
        setContentView(ScrollView(this).apply { addView(root)
            layoutDirection = if (lang in RTL) View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR })
    }

    fun play(f: File) { vv.visibility = View.VISIBLE; vv.setMediaController(MediaController(this)); vv.setVideoURI(Uri.fromFile(f)); vv.start() }

    fun run() {
        problem(mode, custom, input)?.let { logBuf = t(it); logTv.text = logBuf; return }
        busy = true; logBuf = ""; logTv.text = ""; output = null; vv.visibility = View.GONE
        val out = File(cacheDir, "out_${System.currentTimeMillis()}.mp4")
        val total = totalMs(mode, input, isImage)
        pb.isIndeterminate = total <= 0; pb.progress = 0; pct.text = ""; refresh()
        jobId = startJob(buildCmd(this, mode, overlay, custom, input, isImage, out), total, { log(it) },
            { p -> runOnUiThread { pb.progress = p; pct.text = "$p%" } }) { r ->
            runOnUiThread {
                busy = false
                when (r) {
                    0 -> { output = out; log("\n${t("done")} ✔"); play(out)
                        if (saveDir.isNotEmpty()) log("\n" + if (saveToTree(this, saveDir, out)) "${t("saved")} ✔" else "✘") }
                    2 -> log("\n${t("cancelled")}")
                    else -> log("\n${t("fail")} ✘")
                }
                refresh()
            }
        }
    }

    fun pickPreset() {
        val l = loadPresets(this)
        if (l.isEmpty()) { Toast.makeText(this, t("nopre"), Toast.LENGTH_SHORT).show(); return }
        val d = AlertDialog.Builder(this).setTitle(t("presets") + "  (long-press = delete)")
            .setItems(l.map { it.name }.toTypedArray()) { _, i -> mode = "cmd"; custom = l[i].cmd; saveDir = l[i].dir; build() }.create()
        d.show()
        d.listView.setOnItemLongClickListener { _, _, i, _ -> storePresets(this, l - l[i]); d.dismiss(); true }
    }

    fun createPreset() {
        pDir = ""
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), 0) }
        val n = EditText(this).apply { hint = t("pname"); setSingleLine() }
        val c = EditText(this).apply { hint = t("cmd_hint"); typeface = Typeface.MONOSPACE; textSize = 12f; minLines = 3; setText(custom) }
        val dv = TextView(this); dirTv = dv
        box.addView(n); box.addView(c)
        box.addView(Button(this).apply { text = t("pdir"); setOnClickListener { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), 2) } })
        box.addView(dv)
        AlertDialog.Builder(this).setTitle(t("pnew")).setView(box)
            .setPositiveButton(t("psave")) { _, _ ->
                val cmd = c.text.toString()
                if (n.text.isNotBlank() && cmd.contains("{output}")) storePresets(this, loadPresets(this) + Preset(n.text.toString().trim(), cmd.trim(), pDir))
                else Toast.makeText(this, t("need_out"), Toast.LENGTH_SHORT).show()
            }.setNegativeButton(t("close"), null).show()
    }

    override fun onActivityResult(rc: Int, res: Int, d: Intent?) {
        val uri = d?.data
        if (res != RESULT_OK || uri == null) return
        if (rc == 2) {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            pDir = uri.toString(); dirTv?.text = uri.lastPathSegment
        } else Thread {
            val f = File(cacheDir, "input_file")
            contentResolver.openInputStream(uri)?.use { i -> f.outputStream().use { i.copyTo(it) } }
            isImage = contentResolver.getType(uri)?.startsWith("image") == true
            input = f; name = uri.lastPathSegment ?: "file"
            runOnUiThread { nameTv.text = name }
        }.start()
    }
}
