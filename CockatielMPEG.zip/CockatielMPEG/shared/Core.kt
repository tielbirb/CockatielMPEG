package com.cockatiel.mpeg

import android.content.ContentValues
import android.content.Context
import android.graphics.*
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import java.io.File
import java.util.Locale

const val VERSION = "0.0.0.2"
const val CREDITS = "CockatielMPEG v$VERSION\n\nMade with Claude (Anthropic)\n\nFFmpeg: ffmpeg.org\nFFmpegKit by arthenica, Android forks by moizhassankh and JamaisMagic\nAndroid Media3 ExoPlayer (normal build)\n\nIcon: the cockatiel 🦜"
val LANGS = listOf("en", "ar", "ru", "fa", "lol")
val RTL = setOf("ar", "fa")
val KEYS = "upload none hint make busy log save saved done fail m_simple m_cmd cmd_hint need_in need_out cancel cancelled presets pnew pname pdir psave credits close nopre".split(" ")
val L = mapOf(
    "en" to "Upload video / image|No file selected|Text to put on the video|Make video|Rendering...|Log|Save to Movies|Saved to|DONE|FAILED|Simple|FFmpeg command|FFmpeg arguments ({input} {output})|Command uses {input} but no file is selected.|Command must contain {output}.|Cancel|CANCELLED|Select preset|Create preset|Preset name|Select save folder|Save preset|Credits|Close|No presets yet",
    "ar" to "رفع فيديو / صورة|لم يتم اختيار ملف|النص المراد وضعه على الفيديو|إنشاء الفيديو|جارٍ المعالجة...|السجل|حفظ في Movies|تم الحفظ في|تم|فشل|بسيط|أمر FFmpeg|وسائط FFmpeg ({input} {output})|الأمر يستخدم {input} لكن لم يتم اختيار ملف.|يجب أن يحتوي الأمر على {output}.|إلغاء|تم الإلغاء|اختيار إعداد مسبق|إنشاء إعداد مسبق|اسم الإعداد|اختيار مجلد الحفظ|حفظ الإعداد|الشكر والتقدير|إغلاق|لا توجد إعدادات مسبقة",
    "ru" to "Загрузить видео / фото|Файл не выбран|Текст на видео|Создать видео|Рендеринг...|Журнал|Сохранить в Movies|Сохранено в|ГОТОВО|ОШИБКА|Простой|Команда FFmpeg|Аргументы FFmpeg ({input} {output})|Команда использует {input}, но файл не выбран.|В команде должен быть {output}.|Отмена|ОТМЕНЕНО|Выбрать пресет|Создать пресет|Название пресета|Выбрать папку сохранения|Сохранить пресет|Авторы|Закрыть|Пресетов пока нет",
    "fa" to "بارگذاری ویدیو / تصویر|فایلی انتخاب نشده|متنی که روی ویدیو قرار می‌گیرد|ساخت ویدیو|در حال پردازش...|گزارش|ذخیره در Movies|ذخیره شد در|انجام شد|ناموفق|ساده|دستور FFmpeg|آرگومان‌های FFmpeg ({input} {output})|دستور از {input} استفاده می‌کند اما فایلی انتخاب نشده.|دستور باید شامل {output} باشد.|لغو|لغو شد|انتخاب پیش‌تنظیم|ساخت پیش‌تنظیم|نام پیش‌تنظیم|انتخاب پوشه ذخیره|ذخیره پیش‌تنظیم|سازندگان|بستن|هنوز پیش‌تنظیمی نیست",
    "lol" to "UPLOAD TEH VIDEO / PIKCHUR|NO FILEZ SELECTD|WUT TEXT U WANT ON TEH VIDEO|MAEK VIDEO|RENDRIN... PLZ WAIT|LOGZ|SAEV 2 MOOVIEZ|SAEVD 2|DUN|FAIL (SAD CAT)|SIMPLE|FFMPEG COMMAND|FFMPEG ARGZ ({input} {output})|COMMAND NEEDZ {input} BUT NO FILEZ SELECTD|COMMAND NEEDZ {output} PLZ|CANCEL|CANCELD (BAD HUMAN)|PICK PRESET|MAEK PRESET|PRESET NAEM|PICK SAEV FOLDR|SAEV PRESET|CREDITZ|CLOSE|NO PRESETZ YET"
).mapValues { it.value.split("|") }

fun tr(lang: String, k: String) = L[lang]!![KEYS.indexOf(k)]
fun defaultLang() = Locale.getDefault().language.let { if (it in LANGS) it else "en" }

data class Preset(val name: String, val cmd: String, val dir: String)
private fun String.flat() = replace("\t", " ").replace("\n", " ")
fun loadPresets(c: Context): List<Preset> = c.getSharedPreferences("p", 0).getString("l", "")!!.lines()
    .filter { it.isNotBlank() }.map { val p = it.split("\t"); Preset(p[0], p.getOrElse(1) { "" }, p.getOrElse(2) { "" }) }
fun storePresets(c: Context, l: List<Preset>) = c.getSharedPreferences("p", 0).edit()
    .putString("l", l.joinToString("\n") { "${it.name.flat()}\t${it.cmd.flat()}\t${it.dir}" }).apply()

fun problem(mode: String, custom: String, input: File?): String? = when {
    mode == "cmd" && !custom.contains("{output}") -> "need_out"
    mode == "cmd" && custom.contains("{input}") && input == null -> "need_in"
    mode != "cmd" && input == null -> "none"
    else -> null
}

fun totalMs(mode: String, input: File?, image: Boolean): Long = try {
    if (input == null) 0L else if (image) (if (mode == "cmd") 0L else 5000L) else {
        val r = MediaMetadataRetriever(); r.setDataSource(input.path)
        val d = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        r.release(); d
    }
} catch (e: Exception) { 0L }

fun buildCmd(ctx: Context, mode: String, text: String, custom: String, input: File?, image: Boolean, out: File): String {
    val inp = input?.absolutePath ?: ""
    if (mode == "cmd") return "-y " + custom.trim().removePrefix("ffmpeg ").replace("\n", " ").replace("{input}", inp).replace("{output}", out.absolutePath)
    val pre = if (image) "-loop 1 -t 5 -r 25 " else ""
    val scale = "scale=trunc(iw/2)*2:trunc(ih/2)*2"
    val enc = "-c:v mpeg4 -q:v 3 -c:a aac ${out.absolutePath}"
    if (text.isBlank()) return "-y ${pre}-i $inp -vf \"$scale,format=yuv420p\" $enc"
    val (w, h) = probe(input!!, image)
    val png = File(ctx.cacheDir, "text.png"); textBitmap(text, w, h, png)
    return "-y ${pre}-i $inp -i ${png.absolutePath} -filter_complex \"[0:v]$scale[b];[b][1:v]overlay=(W-w)/2:H-h-40,format=yuv420p\" $enc"
}

/** Runs ffmpeg. onProgress gets 0-100. onEnd gets 0 = ok, 1 = failed, 2 = cancelled. Callbacks are NOT on the main thread. */
fun startJob(cmd: String, total: Long, onLog: (String) -> Unit, onProgress: (Int) -> Unit, onEnd: (Int) -> Unit): Long = try {
    FFmpegKit.executeAsync(cmd,
        { s -> onEnd(if (ReturnCode.isSuccess(s.returnCode)) 0 else if (ReturnCode.isCancel(s.returnCode)) 2 else 1) },
        { l -> onLog(l.message) },
        { st -> if (total > 0) onProgress(minOf(100L, st.time.toLong() * 100 / total).toInt()) }).sessionId
} catch (e: Throwable) {
    onLog("FFmpeg could not start on this device: ${e.message}"); onEnd(1); -1L
}
fun cancelJob(id: Long) = FFmpegKit.cancel(id)

fun probe(f: File, image: Boolean): Pair<Int, Int> = try {
    if (image) {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, o); o.outWidth to o.outHeight
    } else {
        val r = MediaMetadataRetriever(); r.setDataSource(f.path)
        val w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 720
        val h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 1280
        val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
        r.release(); if (rot == 90 || rot == 270) h to w else w to h
    }
} catch (e: Exception) { 720 to 1280 }

fun textBitmap(text: String, w: Int, h: Int, out: File) {
    val size = minOf(w, h) / 12f
    val p = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt(); textSize = size }
    val pad = (size / 2).toInt()
    val lw = (w * 0.9f).toInt() - 2 * pad
    val layout = StaticLayout(text, p, lw, Layout.Alignment.ALIGN_CENTER, 1f, 0f, false)
    val bmp = Bitmap.createBitmap(lw + 2 * pad, layout.height + 2 * pad, Bitmap.Config.ARGB_8888)
    val c = Canvas(bmp); c.drawColor(0x99000000.toInt())
    c.translate(pad.toFloat(), pad.toFloat()); layout.draw(c)
    out.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
}

fun save(ctx: Context, f: File): String {
    if (Build.VERSION.SDK_INT >= 29) {
        val v = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, f.name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/CockatielMPEG")
        }
        val uri = ctx.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v) ?: return "?"
        ctx.contentResolver.openOutputStream(uri)?.use { o -> f.inputStream().use { it.copyTo(o) } }
        return "Movies/CockatielMPEG"
    }
    val d = File(ctx.getExternalFilesDir(Environment.DIRECTORY_MOVIES), f.name)
    f.copyTo(d, true); return d.absolutePath
}

fun saveToTree(ctx: Context, tree: String, f: File): Boolean = try {
    val t = Uri.parse(tree)
    val parent = DocumentsContract.buildDocumentUriUsingTree(t, DocumentsContract.getTreeDocumentId(t))
    val doc = DocumentsContract.createDocument(ctx.contentResolver, parent, "video/mp4", f.name)!!
    ctx.contentResolver.openOutputStream(doc)!!.use { o -> f.inputStream().use { it.copyTo(o) } }; true
} catch (e: Exception) { false }
