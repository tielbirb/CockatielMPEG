package com.cockatiel.mpeg

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File

val CmdGreen = Color(0xFF16C60C)
val CmdGray = Color(0xFFCCCCCC)
val CmdBlack = Color(0xFF0C0C0C)
val CmdTrack = Color(0xFF333333)
val CmdColors = darkColorScheme(
    primary = CmdGreen, onPrimary = Color.Black, secondary = Color(0xFF3A96DD),
    background = CmdBlack, onBackground = CmdGray, surface = CmdBlack, onSurface = CmdGray,
    surfaceVariant = Color(0xFF1E1E1E), onSurfaceVariant = CmdGray, outline = Color(0xFF767676)
)
val CmdShapes = Shapes(RectangleShape, RectangleShape, RectangleShape, RectangleShape, RectangleShape)
val CmdType = Typography().run {
    val m = FontFamily.Monospace
    copy(headlineMedium = headlineMedium.copy(fontFamily = m), titleSmall = titleSmall.copy(fontFamily = m),
        bodyLarge = bodyLarge.copy(fontFamily = m), bodyMedium = bodyMedium.copy(fontFamily = m),
        bodySmall = bodySmall.copy(fontFamily = m), labelLarge = labelLarge.copy(fontFamily = m))
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = CmdColors, typography = CmdType, shapes = CmdShapes) { Surface(color = CmdBlack) { App() } } }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var lang by remember { mutableStateOf(defaultLang()) }
    fun t(k: String) = tr(lang, k)
    var mode by remember { mutableStateOf("simple") }
    var input by remember { mutableStateOf<File?>(null) }
    var isImage by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf<String?>(null) }
    var text by remember { mutableStateOf("") }
    var custom by remember { mutableStateOf("-f lavfi -i testsrc=duration=5:size=640x360:rate=25 -pix_fmt yuv420p {output}") }
    var log by remember { mutableStateOf("") }
    var output by remember { mutableStateOf<File?>(null) }
    var busy by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf(0) }
    var jobId by remember { mutableStateOf(0L) }
    var presets by remember { mutableStateOf(loadPresets(ctx)) }
    var saveDir by remember { mutableStateOf("") }
    var menu by remember { mutableStateOf(false) }
    var creating by remember { mutableStateOf(false) }
    var credits by remember { mutableStateOf(false) }
    var pName by remember { mutableStateOf("") }
    var pCmd by remember { mutableStateOf("") }
    var pDir by remember { mutableStateOf("") }
    val logScroll = rememberScrollState()
    LaunchedEffect(log) { logScroll.scrollTo(logScroll.maxValue) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) scope.launch(Dispatchers.IO) {
            val f = File(ctx.cacheDir, "input_file")
            ctx.contentResolver.openInputStream(uri)?.use { i -> f.outputStream().use { i.copyTo(it) } }
            isImage = ctx.contentResolver.getType(uri)?.startsWith("image") == true
            name = uri.lastPathSegment ?: "file"; input = f
        }
    }
    val treePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
        if (uri != null) {
            ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            pDir = uri.toString()
        }
    }

    fun run() {
        problem(mode, custom, input)?.let { log = t(it); return }
        busy = true; log = ""; output = null
        val out = File(ctx.cacheDir, "out_${System.currentTimeMillis()}.mp4")
        val total = totalMs(mode, input, isImage)
        progress = if (total > 0) 0 else -1
        jobId = startJob(buildCmd(ctx, mode, text, custom, input, isImage, out), total, { log += it }, { progress = it }) { r ->
            busy = false
            when (r) {
                0 -> {
                    output = out; log += "\n${t("done")} ✔"
                    if (saveDir.isNotEmpty()) log += "\n" + if (saveToTree(ctx, saveDir, out)) "${t("saved")} ✔" else "✘"
                }
                2 -> log += "\n${t("cancelled")}"
                else -> log += "\n${t("fail")} ✘"
            }
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides if (lang in RTL) LayoutDirection.Rtl else LayoutDirection.Ltr) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp).statusBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(10.dp)) {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Text("CockatielMPEG [Version $VERSION]", style = MaterialTheme.typography.bodySmall)
                Text("C:\\Cockatiel>_", style = MaterialTheme.typography.headlineMedium, color = CmdGreen)
                Row {
                    LANGS.forEach { TextButton({ lang = it }, shape = RectangleShape, contentPadding = PaddingValues(8.dp, 0.dp)) {
                        Text(it.uppercase(), color = if (lang == it) CmdGreen else Color.Gray) } }
                }
            }
            Row {
                listOf("simple" to t("m_simple"), "cmd" to t("m_cmd")).forEach { (k, v) ->
                    TextButton({ mode = k }, shape = RectangleShape) { Text(v, color = if (mode == k) CmdGreen else Color.Gray) }
                }
                Spacer(Modifier.weight(1f))
                TextButton({ credits = true }, shape = RectangleShape) { Text(t("credits")) }
            }
            Box {
                OutlinedButton({ menu = true }, Modifier.fillMaxWidth(), shape = RectangleShape) { Text(t("presets")) }
                DropdownMenu(menu, { menu = false }) {
                    if (presets.isEmpty()) DropdownMenuItem({ Text(t("nopre")) }, { menu = false })
                    presets.forEach { p ->
                        DropdownMenuItem({ Text(p.name) }, { mode = "cmd"; custom = p.cmd; saveDir = p.dir; menu = false },
                            trailingIcon = { Text("✕", Modifier.clickable { presets = presets - p; storePresets(ctx, presets) }) })
                    }
                }
            }
            OutlinedButton({ pName = ""; pCmd = custom; pDir = ""; creating = true }, Modifier.fillMaxWidth(), shape = RectangleShape) { Text(t("pnew")) }
            Button({ picker.launch("*/*") }, Modifier.fillMaxWidth(), shape = RectangleShape) { Text(t("upload")) }
            Text(name ?: t("none"), style = MaterialTheme.typography.bodySmall)
            if (mode == "cmd") {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    OutlinedTextField(custom, { custom = it }, Modifier.fillMaxWidth(), minLines = 3, label = { Text(t("cmd_hint")) },
                        textStyle = LocalTextStyle.current.copy(fontFamily = FontFamily.Monospace, fontSize = 12.sp))
                }
            } else OutlinedTextField(text, { text = it }, Modifier.fillMaxWidth(), label = { Text(t("hint")) })
            Button({ run() }, Modifier.fillMaxWidth(), enabled = !busy, shape = RectangleShape) { Text(if (busy) t("busy") else t("make")) }
            if (busy) {
                OutlinedButton({ cancelJob(jobId) }, Modifier.fillMaxWidth(), shape = RectangleShape) { Text(t("cancel")) }
                if (progress < 0) LinearProgressIndicator(Modifier.fillMaxWidth(), color = CmdGreen, trackColor = CmdTrack)
                else {
                    LinearProgressIndicator({ progress / 100f }, Modifier.fillMaxWidth(), color = CmdGreen, trackColor = CmdTrack)
                    Text("$progress%", style = MaterialTheme.typography.bodySmall)
                }
            }
            Text(t("log"), style = MaterialTheme.typography.titleSmall)
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Box(Modifier.fillMaxWidth().height(180.dp).verticalScroll(logScroll)) {
                    Text(log, fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = CmdGreen)
                }
            }
            output?.let { f ->
                Player(f)
                OutlinedButton({ Toast.makeText(ctx, "${t("saved")} ${save(ctx, f)}", Toast.LENGTH_LONG).show() },
                    Modifier.fillMaxWidth(), shape = RectangleShape) { Text(t("save")) }
            }
        }

        if (credits) AlertDialog({ credits = false }, confirmButton = { TextButton({ credits = false }) { Text(t("close")) } },
            title = { Text(t("credits")) }, text = { Text(CREDITS, style = MaterialTheme.typography.bodySmall) })

        if (creating) AlertDialog({ creating = false },
            title = { Text(t("pnew")) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(pName, { pName = it }, label = { Text(t("pname")) }, singleLine = true)
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                        OutlinedTextField(pCmd, { pCmd = it }, minLines = 3, label = { Text(t("cmd_hint")) },
                            textStyle = LocalTextStyle.current.copy(fontFamily = FontFamily.Monospace, fontSize = 12.sp))
                    }
                    OutlinedButton({ treePicker.launch(null) }, shape = RectangleShape) { Text(t("pdir")) }
                    if (pDir.isNotEmpty()) Text(Uri.parse(pDir).lastPathSegment ?: pDir, style = MaterialTheme.typography.bodySmall)
                }
            },
            confirmButton = {
                TextButton({
                    if (pName.isNotBlank() && pCmd.contains("{output}")) {
                        presets = presets + Preset(pName.trim(), pCmd.trim(), pDir); storePresets(ctx, presets); creating = false
                    } else Toast.makeText(ctx, t("need_out"), Toast.LENGTH_SHORT).show()
                }) { Text(t("psave")) }
            },
            dismissButton = { TextButton({ creating = false }) { Text(t("close")) } })
    }
}

@Composable
fun Player(file: File) {
    val ctx = LocalContext.current
    val player = remember(file) {
        ExoPlayer.Builder(ctx).build().apply { setMediaItem(MediaItem.fromUri(Uri.fromFile(file))); prepare(); playWhenReady = true }
    }
    DisposableEffect(player) { onDispose { player.release() } }
    AndroidView({ PlayerView(it) }, Modifier.fillMaxWidth().height(260.dp), update = { it.player = player })
}
