plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
android {
    namespace = "com.cockatiel.mpeg"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.cockatiel.mpeg"
        minSdk = 28; targetSdk = 35; versionCode = 2; versionName = "0.0.0.2"
        ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a") }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    sourceSets { getByName("main") { java.srcDir("../shared") } }
    buildFeatures { compose = true }
    packaging { jniLibs.useLegacyPackaging = true }
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.00"))
    implementation("androidx.compose.material3:material3")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.media3:media3-exoplayer:1.4.1")
    implementation("androidx.media3:media3-ui:1.4.1")
    // FFmpegKit was retired upstream; this is a maintained fork. Swap if it ever disappears.
    implementation("com.moizhassan.ffmpeg:ffmpeg-kit-16kb:6.1.1")
}
